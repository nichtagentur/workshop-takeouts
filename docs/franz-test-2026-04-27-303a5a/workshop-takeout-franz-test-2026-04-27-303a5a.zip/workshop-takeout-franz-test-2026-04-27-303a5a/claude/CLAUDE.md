# AI Workshop Cloud Desktop

You are Claude Code on a Hetzner Cloud Desktop for an AI Workshop. See `~/WORKSHOP.md` for the upcoming workshop(s) this desktop is provisioned for. The general workshop tooling, accounts, and aliases below apply to every workshop on this golden.

IMPORTANT: At session start, state current date (from system) and your Knowledge Cutoff Date. Read all files referenced in "Key Files" below. Confirm understood.

## Rules
- Tasks must be pragmatic -- complete in 3-5 minutes max
- Simple, working code wins -- no complex solutions
- Short, clear explanations for non-technical audience
- New projects: ~/Projects/<name>/ with CLAUDE.md + AGENTS.md symlink
- **NEVER** tell users to do things manually -- YOU do it
- **NEVER use `rm`** -- use `gio trash <file>` instead
- **ALWAYS use Chrome** as browser
- Do NOT use emoji in responses (renders as boxes in this terminal)
- You have `sudo` access -- use it when needed

## Password (ALL ACCOUNTS)
```
[REDACTED-WORKSHOP_PASSWORD]
```

## API Keys (~/.env)

Source: `~/.env` (single source of truth, sourced by ~/.bashrc)

| Variable | Service | Purpose |
|----------|---------|---------|
| `CLAUDE_API_KEY_1` | Anthropic | Account 1 (franz@fso, Tier 2) |
| `CLAUDE_API_KEY_2` | Anthropic | Account 2 (team@fso, Tier 1) |
| `OPENROUTER_API_KEY` | OpenRouter | Multi-model access (100+ models) |
| `OPENAI_API_KEY` | OpenAI | Codex CLI + all OpenAI services |
| `GEMINI_API_KEY` | Google | Gemini CLI |
| `GITHUB_TOKEN` | GitHub | gh CLI (nichtagentur, no expiry) |
| `VERCEL_TOKEN` | Vercel | Deploys (never expires) |
| `TAILSCALE_AUTHKEY` | Tailscale | VPN auth |
| `DATAFORSEO_LOGIN` | DataForSEO | SERP / keywords / backlinks (Basic-Auth login) |
| `DATAFORSEO_PASSWORD` | DataForSEO | Basic-Auth password |
| `SMTP_HOST` / `SMTP_USER` / `SMTP_PASS` | easyname.eu | Outbound mail (port 587 STARTTLS) |

## Git
```
user.name = nichtagentur
user.email = [REDACTED-WORKSHOP_EMAIL]
init.defaultBranch = main
```

## GitHub
- **Username:** nichtagentur
- **Email:** [REDACTED-WORKSHOP_EMAIL]
- **Password:** [REDACTED-WORKSHOP_PASSWORD]

## Vercel
- **Account:** nichtagentur (via GitHub)
- **Token:** `VERCEL_TOKEN` in ~/.env

## Email

| Email | Purpose |
|-------|---------|
| [REDACTED-WORKSHOP_EMAIL] | GitHub account |
| [REDACTED-WORKSHOP_EMAIL] | Default user (SMTP sender) |
| [REDACTED-WORKSHOP_EMAIL] | Support |
| [REDACTED-WORKSHOP_EMAIL] | AI assistant |

**Server:** [REDACTED-WORKSHOP_SMTP_HOST] | IMAP: 993 (SSL) | SMTP: 587 (STARTTLS) -- port 465 blocked by Hetzner

## CLI Aliases

| Alias | Description |
|-------|-------------|
| `claude+` | Claude auto-approve |
| `claude++` | Claude auto-approve + continue |
| `codex+` | Codex YOLO (pinned `gpt-5.5`) |
| `codex++` | Codex resume + YOLO |
| `gemini+` | Gemini auto-approve |
| `gemini++` | Gemini resume + auto |
| `vercel+` | Vercel with token |
| `email` | Open mutt |

## Publishing

| Type | Command |
|------|---------|
| Static sites | `gh repo create && gh pages deploy` |
| Apps | `vercel+` |

## Tools

| Tool | Command | Notes |
|------|---------|-------|
| Python | `python3` | 3.12+ |
| Node.js | `node` | v22+ |
| Claude Code | `claude+` | latest |
| Codex | `codex+` | pinned `gpt-5.5` |
| Gemini | `gemini+` | latest |
| GitHub | `gh` | nichtagentur |
| Vercel | `vercel+` | latest |

## Key Files

| File | Purpose |
|------|---------|
| `~/.env` | ALL API keys (single source) |
| `~/.bashrc` | Aliases, sources ~/.env |
| `~/.claude/CLAUDE.md` | THIS FILE |
| `~/.gsc/token.json` | YOUR Google OAuth token (created by `gsc-login`, mode 600) |
| `~/.workshop/participant.json` | Your name + email for `takeout` |
| `~/.workshop/beamer-url` | Your secret beamer URL |
| `~/WORKSHOP.md` | Current workshop(s) running on this desktop |
| `~/MODELS.md` | Current AI models, defaults, pricing tiers |
| `~/KNOWN-ISSUES.md` | Known issues & fixes |
| `~/OPENCLAW-SETUP.md` | OpenClaw / agent server setup |
| `~/Projects/` | Workshop project folders (`takeout` packs these) |
| `~/Screenshots/` | Screenshots |

---

# Workshop tooling (workshop-agnostic)

The following lives on every cloned worker, regardless of which workshop is running.

## What's on this desktop

- `~/Projects/` -- scratch space. Anything in here can be packed up at the end with **Takeout My Work**.
- `~/Data/` -- shared sample datasets for hands-on work.
- `~/Screenshots/` -- screenshots.

## SERP & web data source

**DataForSEO** (`$DATAFORSEO_LOGIN` / `$DATAFORSEO_PASSWORD` already in `~/.env`):
HTTP Basic Auth against `https://api.dataforseo.com/v3/...`. Use for live SERPs, keyword volume, backlinks, on-page audit, AI Overview detection. Example one-liner:

```bash
curl -s -u "$DATAFORSEO_LOGIN:$DATAFORSEO_PASSWORD" \
  -H "Content-Type: application/json" \
  -d '[{"keyword":"your keyword","location_code":2040,"language_code":"de","device":"desktop"}]' \
  https://api.dataforseo.com/v3/serp/google/organic/live/advanced | jq '.tasks[0].result[0].items[]?.title' | head
```

Endpoints worth knowing:
- `/v3/serp/google/organic/live/advanced` -- live Google SERP for any keyword
- `/v3/keywords_data/google/search_volume/live` -- monthly volume + trend
- `/v3/serp/google/ai_mode/live/advanced` -- Google AI Mode results (when available)
- `/v3/on_page/instant_pages` -- render + audit one URL
- `/v3/backlinks/summary/live` -- backlink profile of a domain

Account is shared across all workshop seats -- keep query volume sane.

## Common commands

### Beamer -- drag-drop files onto this desktop from your phone
Double-click **Open Beamer (file drop)** on the desktop. A page opens with a drop zone. The URL is also in `~/.workshop/beamer-url`. Open it on your phone, drop a screenshot or PDF, it lands in `~/Desktop/` here.

### `takeout` -- pack your work, push to GitHub, email yourself
When you're done, double-click **Takeout My Work** or run `takeout`. For each folder in `~/Projects/`:
1. Strips known API keys (Anthropic, OpenAI, Google, GitHub, Vercel, Tailscale)
2. Creates a private GitHub repo on the workshop org and pushes
3. Emails you the list of repo URLs

You'll see them in your inbox in under a minute.

## Hard rules
- **Never paste an API key into chat or commit one.** `takeout` strips them automatically; you should never need to.
- No emoji in terminal output (VNC + 16-bit color renders them as boxes).
- `~/.env` is shared across the worker -- don't break it for the next participant.
