# Workshop Takeout — Jonas Reithner

Generated 2026-06-11. Download URL: [https://nichtagentur.github.io/workshop-takeouts/jonas-reithner-2026-06-11-8cab7e/workshop-takeout-jonas-reithner-2026-06-11-8cab7e.zip](https://nichtagentur.github.io/workshop-takeouts/jonas-reithner-2026-06-11-8cab7e/workshop-takeout-jonas-reithner-2026-06-11-8cab7e.zip)

Delivered to: `j.reithner@gmail.com`

This archive contains everything you need to recreate the workshop's
Claude Code / Codex / Gemini setup on your own machine, **plus your own
work in `projects/`**. It contains **no API keys** and no shared workshop
credentials — every known secret pattern was scrubbed and a final regex
gate refused to publish if anything matched.

## What's included

- `claude/CLAUDE.md` — the system prompt the workshop golden uses
- `claude/settings.json` — Claude Code settings (effortLevel, MCP, allow list)
- `codex/config.toml` — Codex CLI config (pinned model)
- `shell/bashrc-snippet` — the AI CLI aliases (`claude+`, `codex+`, `gemini+`, etc.)
- `shell/env-template` — list of env vars you need (placeholders, no values)
- `projects/` — your work from `~/Projects/`
- `manifest.json` — file list + SHA-256 of this archive

## What was stripped

| Stripped | Why |
|---|---|
| `~/.env` (the file with API keys) | All keys are workshop-shared, not yours |
| `~/.codex/auth.json` | Contains the workshop's OpenAI key |
| `~/.config/gh/hosts.yml` | Workshop GitHub PAT |
| `~/.config/google-chrome/` | Cookies, OAuth sessions |
| `~/.gemini/` | Google OAuth state |
| `~/.muttrc` | Workshop SMTP credentials |
| `~/Desktop/`, `~/Data/`, `~/Pictures/`, etc. | Demo assets, not your work |
| Workshop password literal | Never share |
| Workshop email addresses | Workshop-shared accounts |

The pipeline ran a final regex gate against known key-shape patterns
(Anthropic, OpenAI, OpenRouter, Google AI, GitHub, Tailscale, Slack,
AWS, JWT) and refused to publish if anything matched. If you find an
unredacted secret in this archive, **that is a bug** — please report it
to the trainer.

## How to recreate this on your own machine

### 1. Install the CLIs

```bash
npm i -g @anthropic-ai/claude-code @openai/codex @google/gemini-cli vercel
brew install gh   # or: apt install gh
```

### 2. Get your own API keys

You need to obtain these yourself (workshop keys are not shared).

```text
ANTHROPIC_API_KEY    https://console.anthropic.com/settings/keys
OPENAI_API_KEY       https://platform.openai.com/api-keys
GEMINI_API_KEY       https://aistudio.google.com/apikey
GITHUB_TOKEN         https://github.com/settings/tokens
VERCEL_TOKEN         https://vercel.com/account/tokens
```

### 3. Set up `~/.env`

Copy `shell/env-template` to `~/.env`, fill in your keys, then add to your `~/.bashrc`:

```bash
[ -f ~/.env ] && set -a && source ~/.env && set +a
```

### 4. Add the aliases

Append `shell/bashrc-snippet` to your `~/.bashrc`.

### 5. Drop the configs in place

```bash
mkdir -p ~/.claude ~/.codex
cp claude/CLAUDE.md     ~/.claude/CLAUDE.md
cp claude/settings.json ~/.claude/settings.json
cp codex/config.toml    ~/.codex/config.toml
```

### 6. Verify

```bash
claude --version && codex --version && gemini --version
```

If `claude/settings.json` references `/usr/local/bin/claude-api-key-helper.sh`,
either install that helper (rotates between two Anthropic keys) or remove the
`apiKeyHelper` field and let the CLI use `ANTHROPIC_API_KEY` directly.

## Your projects

`projects/` is your own work. It has been scrubbed for known secret
patterns but not otherwise modified. Re-init git locally with
`git init` in each subfolder and push to your own GitHub if you want.

— Workshop Takeout, 2026-06-11
