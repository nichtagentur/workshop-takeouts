# AI Workshop Cloud Desktop

Claude Code on a Hetzner Cloud Desktop. Tooling, accounts, aliases below apply to every clone of this golden.

## Session start (every new session)

State current date+time (system clock) + knowledge cutoff. Identify the participant (below). Identify the workshop day from the schedule below.

```bash
date '+%Y-%m-%d %H:%M %Z (%A)'
cat ~/.workshop/identity.json
```

## Workshop on this golden

**AI Computer Use -- From Zero to Your Own Solution** (Apps, Automations, Agents -- No Code Required). Open-enrollment, mixed companies; each participant builds their own real solution in one day. Language: English.

- **Trainer:** Franz Enzenhofer -- [REDACTED-TRAINER_EMAIL]
- **Co-trainer:** Jonas Reithner

| Date | Location | Hours |
|------|----------|-------|
| 2026-06-11 (Thu) | **Ibis Wien Mariahilf** -- Mariahilfer Guertel 22-24, 1060 Vienna | 09:00-18:00 (17:30 + buffer), max 12 |

Tools: Claude Code (primary), MCP servers (Google Sheets, Gmail, Trello, Freshdesk, Playwright, ...), Gemini VEO3 + Nanobanana, OpenRouter. Generic example datasets under `~/Data/`. More in `~/WORKSHOP.md`.

If today matches a workshop date: lead with `Today is <date>. This is the AI Computer Use workshop in <location>.` Else: `Today is <date>. No workshop scheduled.`

## Who is this participant

One participant per desktop. `~/.workshop/identity.json`:

```bash
cat ~/.workshop/identity.json   # displayName, email, instanceLabel
```

- Address by `displayName`.
- `email` = claim token, not a live mailbox here.
- `instanceLabel` = friendly name ("Desktop NN").
- Missing JSON: fall back to `~/Desktop/WHO-AM-I.txt` or `aifcd-whoami`.

## Rules
- Tasks pragmatic, 3-5 min max; simple working code; short non-technical explanations
- New project: `~/Projects/<name>/` with `CLAUDE.md` + `AGENTS.md` symlink
- **NEVER** tell users to do things manually -- YOU do it
- **NEVER use `rm`** -- use `gio trash <file>`
- **ALWAYS** use Chrome -- and always the **VISIBLE** Chrome window (`~/bin/google-chrome-cdp`, the on-screen browser the chrome-devtools MCP attaches to on `:9222`), never a headless/background browser, so the user can watch what happens live. Only use a non-visible browser if the user explicitly asks.
- No emoji (renders as boxes in this terminal)
- You have `sudo`

## Quick start
```bash
claude+ "your task"    # auto-approve
codex+ "your task"     # codex YOLO
gemini+ "your task"    # gemini auto
```

## Password (ALL ACCOUNTS)
```
[REDACTED-WORKSHOP_PASSWORD]
```

## API Keys (`~/.env`, sourced by `~/.bashrc`)

Anthropic key is NOT in `~/.env` -- `/usr/local/bin/claude-api-key-helper.sh` (referenced by `apiKeyHelper` in `~/.claude/settings.json`) supplies it. Don't add `ANTHROPIC_API_KEY` to `~/.env`; it conflicts. See `~/KNOWN-ISSUES.md`.

| Variable | Service | Purpose |
|----------|---------|---------|
| `OPENROUTER_API_KEY` | OpenRouter | 100+ models |
| `OPENAI_API_KEY` | OpenAI | Codex + OpenAI services |
| `GEMINI_API_KEY` | Google | Gemini CLI |
| `GITHUB_TOKEN` | GitHub | gh CLI (nichtagentur, no expiry) |
| `VERCEL_TOKEN` | Vercel | Deploys |
| `TAILSCALE_AUTHKEY` | Tailscale | VPN |
| `DATAFORSEO_LOGIN` / `..._PASSWORD` | DataForSEO | SERP/keywords/backlinks |
| `SMTP_HOST` / `SMTP_USER` / `SMTP_PASS` | easyname.eu | Outbound mail (587 STARTTLS) |
| `GOOGLE_WORKSHOP_EMAIL` / `_PASSWORD` / `_RECOVERY_PHONE` | Google | Workshop demo account (`niceshopsworkshop@gmail.com`) |
| `GOOGLE_WORKSHOP_TOTP_SECRET` | Google | Base32 2FA secret -- AI solves the authenticator prompt itself |
| `GOOGLE_OAUTH_CLIENT_ID` / `_CLIENT_SECRET` / `_REFRESH_TOKEN` | Google | Browserless REST access to all Google APIs (GCP project `aifcd-workshop-api`, desktop OAuth client, production -> non-expiring token) |
| `GMAIL_USER` / `GMAIL_APP_PASSWORD` | Google | Gmail over IMAP/SMTP from the command line (app password; independent of OAuth) |

A value of `%noapikeyset%` means intentionally unprovisioned (e.g. no Codex this workshop) -- tools fail loud, not silent.

### Project-specific accounts (energy-saas workshop project)

The `~/Projects/energy-saas/` project has its own dedicated **free-tier** accounts under the
nichtagentur identity (kept out of `~/.env` on purpose; they live in the project's `.env`,
which is that project's SSOT, and are mirrored in `~/Projects/energy-saas/CLAUDE.md`):

- **Cloudflare** -- own free account `[REDACTED-WORKSHOP_EMAIL]` (account id `66c2f5e833ad1875b0a294917c4a59c7`), all-powerful Workers API token. NOT Franz's Cloudflare account.
- **Turso** -- libSQL, `nichtagentur` org; platform token lets each desktop create its own db.
- **Clerk** -- dev instance (Google social login).
- **Resend** -- own account (signed up via GitHub `[REDACTED-WORKSHOP_EMAIL]`); 100 mails/day free tier.

Credentials for these are read from `~/Projects/energy-saas/.env`, never from `~/.env`.

## Google automation (workshop demo account)

Full AI control of `niceshopsworkshop@gmail.com` -- browser and API. Skills: `google-login`, `google-2fa`, `google-api`.

- **TOTP:** `~/bin/totp` prints the current 2FA code (`oathtool` + `GOOGLE_WORKSHOP_TOTP_SECRET`). The AI satisfies Google's authenticator prompt with no human.
- **Browser:** `~/bin/google-chrome-cdp` launches Chrome on the signed-in clone profile (`~/.config/google-chrome-cdp`) with remote debugging on `:9222`, `navigator.webdriver=false`. chrome-devtools MCP attaches via `--browserUrl` (set in `~/.claude.json` + `~/.claude-max/.claude.json`). Google blocks fresh logins from MCP/puppeteer-launched Chrome (automation flag) -- always attach to this instead.
- **API:** `~/bin/google-access-token` mints an access token from the OAuth refresh token. GCP project `niceshops-workshop-automation`, app published to production, scopes for Gmail/Drive/Calendar/Docs/Sheets/Slides/Forms/People. Example: `curl -H "Authorization: Bearer $(google-access-token)" https://gmail.googleapis.com/gmail/v1/users/me/profile`.

## Git
```
user.name = nichtagentur
user.email = [REDACTED-WORKSHOP_EMAIL]
init.defaultBranch = main
```

## GitHub / Vercel
- **GitHub:** user `nichtagentur`, email `[REDACTED-WORKSHOP_EMAIL]`, password above.
- **GitHub token:** `GITHUB_TOKEN` in `~/.env` is an **all-powerful classic PAT** (every scope incl. `repo`, `delete_repo`, `admin:*`, `workflow`, `gist`, `user`; **no expiration**). Bypasses 2FA for all `gh`/`git`/API use. Full access details in `~/.github-recovery.txt`.
- **GitHub browser login:** password (above) + a **2FA recovery code** from `~/bin/github-recovery-codes.txt` (at the 2FA prompt: "More options -> 2FA recovery code"). 14 codes remain.
- **Vercel:** account `nichtagentur` (team `nichtagenturs-projects`). `VERCEL_TOKEN` in `~/.env` is an **all-power full-account token** (no scope limits). Use `vercel+`.

## Email

| Email | Purpose |
|-------|---------|
| [REDACTED-WORKSHOP_EMAIL] | GitHub account |
| [REDACTED-WORKSHOP_EMAIL] | Default SMTP sender |
| [REDACTED-WORKSHOP_EMAIL] | Support |
| [REDACTED-WORKSHOP_EMAIL] | AI assistant |

`[REDACTED-WORKSHOP_SMTP_HOST]` | IMAP 993 SSL | SMTP 587 STARTTLS (465 blocked by Hetzner).

## CLI Aliases

| Alias | Description |
|-------|-------------|
| `claude+` / `claude++` | Claude auto-approve / + continue |
| `codex+` / `codex++` | Codex YOLO / + resume |
| `gemini+` / `gemini++` | Gemini auto / + resume |
| `vercel+` | Vercel with token |
| `email` | Open mutt |

## Publishing
- Static sites: `gh repo create && gh pages deploy`
- Apps: `vercel+`

## Tools
- `python3`, `node` -- latest via linuxbrew
- `claude+` / `codex+` / `gemini+` -- latest CLIs
- `gh` (nichtagentur), `vercel+`

## Installing a personal "claw" agent

Telegram + agent bridge -- recommend **MVPClaw**:

```bash
git clone https://github.com/Arthur-Ficial/mvpclaw.git mybot
cd mybot
claude        # then: "make this work"
```

Small single-process Telegram-to-agent bridge (OpenRouter by default, or Claude CLI). The coding agent is the installer.

## Key Files

| File | Purpose |
|------|---------|
| `~/.env` | ALL API keys (single source) |
| `~/.bashrc` | Aliases, sources `~/.env` |
| `~/.claude/CLAUDE.md` | THIS FILE -- master config |
| `~/CLAUDE.md` | Pointer to this file |
| `~/.claude/settings.json` | Claude defaults (`opus[1m]`, effort `medium`) |
| `~/.workshop/identity.json` | Participant name + email + desktop label |
| `~/WORKSHOP.md` | Workshop notes (current workshop detail) |
| `~/.github-recovery.txt` | GitHub full access + recovery (PAT, password, codes) -- chmod 600 |
| `~/bin/github-recovery-codes.txt` | GitHub 2FA one-time recovery codes |
| `~/.google-workshop-recovery.txt` | Active Google account access + 2FA backup codes -- chmod 600 |
| `~/stashed-new-google-account.txt` | Paused `nichtagentur@gmail.com` account setup |
| `~/old_workshops.md` | Archived finished-workshop references (niceshops) |
| `~/KNOWN-ISSUES.md` | Known issues |
| `~/Projects/` | Workshop project folders |
| `~/Screenshots/` | Screenshots |

---

# Workshop tooling (workshop-agnostic)

Lives on every cloned worker.

## What's on this desktop
- `~/Projects/` -- scratch space
- `~/Data/` -- shared sample datasets
- `~/Screenshots/` -- screenshots

## SERP & web data: DataForSEO

`$DATAFORSEO_LOGIN` / `$DATAFORSEO_PASSWORD` in `~/.env`. HTTP Basic Auth against `https://api.dataforseo.com/v3/...`:

```bash
curl -s -u "$DATAFORSEO_LOGIN:$DATAFORSEO_PASSWORD" \
  -H "Content-Type: application/json" \
  -d '[{"keyword":"your keyword","location_code":2040,"language_code":"de","device":"desktop"}]' \
  https://api.dataforseo.com/v3/serp/google/organic/live/advanced | jq '.tasks[0].result[0].items[]?.title' | head
```

Endpoints: `/v3/serp/google/organic/live/advanced` (live SERP), `/v3/keywords_data/google/search_volume/live` (volume + trend), `/v3/serp/google/ai_mode/live/advanced` (AI Mode), `/v3/on_page/instant_pages` (render+audit URL), `/v3/backlinks/summary/live` (backlinks). Shared account -- keep volume sane.

## Common commands

### Vercel deployments -- share the right URL, it's public

Team `nichtagentur's projects` (`team_3s3xefp75oAjdzqQ5PLDnYrr`, Hobby Plus plan). After `vercel deploy --yes --prod` you get TWO URLs:

| URL pattern | Public? | Share it? |
|---|---|---|
| Production alias (the `Aliased: ...` line from CLI output) | **YES, HTTP 200** | **YES -- share this one** |
| `<project>-<hash>-nichtagenturs-projects.vercel.app` (preview) | NO, HTTP 401 SSO wall | No (unless you PATCH) |

**CRITICAL: never assume `<project>.vercel.app` is yours.** The short `<project>.vercel.app` name is a GLOBAL namespace across all Vercel users -- if someone else registered it first (common for generic names like `hello-vercel`, `todo`, `app`), Vercel silently assigns you a suffixed alias instead (e.g. `<project>-nine-rho.vercel.app`). Sharing the short name will send users to a stranger's site.

**Always** read the actual production alias from the deploy output's `Aliased: ...` line, or run `vercel alias ls --scope nichtagenturs-projects | grep <project>` to confirm. Curl it (`curl -sI <url>`) before sharing to verify it returns your content, not someone else's.

**Only if you really need a specific preview URL public** (e.g. branch deploy for review), one curl makes the whole project's preview URLs public too:
```bash
TEAM=team_3s3xefp75oAjdzqQ5PLDnYrr   # nichtagentur's projects
curl -X PATCH -H "Authorization: Bearer $VERCEL_TOKEN" \
  "https://api.vercel.com/v9/projects/<project-name>?teamId=$TEAM" \
  -d '{"ssoProtection":null}'
```
Or dashboard: `vercel.com/nichtagenturs-projects/<project>/settings/deployment-protection` -> Disabled. (Team-wide "no protection by default" is a Pro/Enterprise feature; we're on Hobby Plus so each new project starts with SSO on its preview URLs until PATCHed.)

### `takeout` -- pack work, push to GitHub, email
**Takeout My Work** (or `takeout`): per `~/Projects/` folder strips known API keys, pushes to private workshop-org repo, emails URLs.

## Hard rules
- **Never paste an API key into chat or commit.** `takeout` strips them.
- No emoji (VNC + 16-bit color -> boxes).
- `~/.env` shared across workers -- don't break it.

---

## Local LLM Tooling (preinstalled, not auto-integrated)

Outside `~`, so `takeout` excludes them.

### Nemotron-3-Nano-4B via Ollama
- `ollama` systemd daemon, OpenAI-compat at `http://127.0.0.1:11434/v1`
- Model: `nemotron-3-nano:4b` (2.8 GB)
- Test: `ollama run nemotron-3-nano:4b "hi"`
- API (suppress reasoning):
  ```
  curl -s http://127.0.0.1:11434/v1/chat/completions \
    -H "Content-Type: application/json" \
    -d '{"model":"nemotron-3-nano:4b","messages":[{"role":"user","content":"hi"}],"reasoning_effort":"none"}'
  ```
- NVIDIA Open Model license (commercial OK). Invoke explicitly.

### Whisper.cpp (local CPU transcription)
- Binary: `/opt/whisper.cpp/build/bin/whisper-cli`, wrapper: `/usr/local/bin/whisper`
- Model: `ggml-base.en.bin` (142 MB, English). Usage: `whisper my.wav` -> stdout + `my.wav.txt`. MIT.

## XDG_RUNTIME_DIR

If systemd-user says "Systemd user services unavailable": `echo $XDG_RUNTIME_DIR` should be `/run/user/1000`. If empty: `export XDG_RUNTIME_DIR=/run/user/$(id -u)`. Golden ships `/etc/profile.d/xdg-runtime-dir.sh` so login shells auto-set it.

## Google workshop account (for demos)

Active demo Google account: login **`niceshopsworkshop@gmail.com`** (display name now **"Nichtagentur Workshop"** -- the `@gmail.com` login cannot be renamed, only the display name). All credentials in `~/.env`:
- **Login / password:** `GOOGLE_WORKSHOP_EMAIL` (`niceshopsworkshop@gmail.com`) / `GOOGLE_WORKSHOP_PASSWORD` (`niceshops2026!`).
- **2FA TOTP:** `GOOGLE_WORKSHOP_TOTP_SECRET` -> `~/bin/totp` prints a live code (skill `google-2fa`).
- **Recovery phone:** `GOOGLE_WORKSHOP_RECOVERY_PHONE`; **recovery email:** `[REDACTED-WORKSHOP_EMAIL]` (verified).
- **Backup codes** + full recovery details: `~/.google-workshop-recovery.txt`.
- **API (REST):** `GOOGLE_OAUTH_*` (CLIENT_ID/_SECRET/_REFRESH_TOKEN) -> `google-access-token`. GCP project **`aifcd-workshop-api`** (desktop OAuth client, **published to production** so the refresh token does **not** expire; OAuth-cap 100 users, "unverified app" consent screen). Working APIs (all HTTP 200): **Gmail, Drive (full), Sheets, Docs, Slides, Calendar, Forms, Search Console (webmasters), Tasks**.
  - **Granted scopes:** `openid`, `email`, `https://mail.google.com/`, `.../auth/drive`, `.../auth/spreadsheets`, `.../auth/presentations`, `.../auth/documents`, `.../auth/forms.body`, `.../auth/calendar`, `.../auth/contacts`, `.../auth/tasks`, `.../auth/webmasters`. (To also use the People API add `.../auth/userinfo.profile` and re-consent -- currently 403, unused.)
  - **Re-mint the refresh token** (if ever revoked): run a loopback OAuth flow with the desktop client + those scopes (`access_type=offline&prompt=consent`, redirect `http://localhost:8765`), then exchange the code at `oauth2.googleapis.com/token`. Helper left at `~/oauth_catcher.py`.
  - NOTE: the old project `niceshops-workshop-automation` was Google-suspended (AUP) and abandoned -- do not use it.
- **Gmail via command line** (IMAP/SMTP, independent of OAuth): `GMAIL_USER` / `GMAIL_APP_PASSWORD` in `~/.env` -> `imap.gmail.com:993` (read) + `smtp.gmail.com:587` (send), same as the easyname mailboxes.

Browser (`google-chrome-cdp`) is logged into this account; skills `google-login`/`google-2fa`/`google-api` all target it.

> A second account ("Nichtagentur Workshop", identifier `u0377237026@id.gle`) was started to get a `nichtagentur@gmail.com` address but is **stashed/incomplete** (Gmail-address step needs SMS verification; phone rate-limited). Details in `~/stashed-new-google-account.txt`. Finished niceshops workshop archived in `~/old_workshops.md`.
