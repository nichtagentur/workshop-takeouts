#!/usr/bin/env python3
import json, base64, os, html

ROOT = os.path.dirname(os.path.abspath(__file__))
res = {r["id"]: r for r in json.load(open(os.path.join(ROOT, "results.json")))}

# ---- group every surface under a named SERVICE, in display order ----
GROUPS = [
 ("Anthropic (Claude)",        ["anth-k1","anth-k2","anth-cli"]),
 ("OpenRouter",                ["or"]),
 ("OpenAI",                    ["oai"]),
 ("Google Gemini",            ["gem-api","gem-or"]),
 ("GitHub",                    ["gh-cli","gh-scopes","gh-priv","gh-2fa","br-github"]),
 ("Vercel",                    ["vc-cli","vc-pub"]),
 ("Tailscale (VPN)",          ["ts"]),
 ("DataForSEO (SERP/SEO)",    ["dfs"]),
 ("Email - easyname",         ["smtp","imap"]),
 ("Gmail (app password)",     ["gmail-imap","gmail-smtp"]),
 ("Google Workspace APIs",    ["g-token","g-gmail","g-drive","g-gsc","g-totp","g-newproj","g-tasks"]),
 ("Google - browser session", ["br-google"]),
 ("Local LLM - Ollama",       ["ollama"]),
 ("Local STT - Whisper",      ["whisper"]),
 ("Documented model IDs - latest?", ["mdl-opus","mdl-gflash"]),
 ("energy-saas (own free-tier accounts)", ["cf","turso","clerk","resend"]),
]

BYDESIGN = {"gem-api"}

def cls(r):
    if r["status"]=="pass": return "pass"
    if r["status"]=="na": return "na"
    if r["id"] in BYDESIGN: return "design"
    return "bad"

def esc(s): return html.escape(str(s))
def b64(name):
    p=os.path.join(ROOT,"screenshots",name)
    return "data:image/png;base64,"+base64.b64encode(open(p,"rb").read()).decode() if os.path.exists(p) else None

allr=list(res.values())
n_pass=sum(1 for r in allr if r["status"]=="pass")
n_fail=sum(1 for r in allr if r["status"]=="fail")
n_gap =sum(1 for r in allr if r["status"]=="gap")

# group roll-up status: bad if any real-bad, else design if any design, else pass
def group_state(ids):
    cs=[cls(res[i]) for i in ids if i in res]
    if "bad" in cs: return "bad"
    if any(c=="design" for c in cs) and all(c in("design","pass","na") for c in cs) and "bad" not in cs:
        return "design" if all(c!="pass" for c in cs) else "mixed"
    return "pass"

BADGE={"pass":"PASS","fail":"FAIL","gap":"GAP","na":"N/A"}

# ---- service cards ----
cards=""
gaps_by_service=[]
for name,ids in GROUPS:
    rows=[res[i] for i in ids if i in res]
    if not rows: continue
    st=group_state(ids)
    bad_here=[r for r in rows if cls(r)=="bad"]
    if bad_here: gaps_by_service.append((name,bad_here))
    head_cls={"bad":"hbad","pass":"hpass","design":"hdesign","mixed":"hmixed"}[st]
    inner=""
    for r in rows:
        c=cls(r)
        inner+=f'<tr class="{c}"><td class="surf">{esc(r["surface"])}</td><td class="b {c}">{BADGE[r["status"]]}</td><td class="det">{esc(r["detail"])}</td></tr>'
    cards+=f'<div class="card {head_cls}"><div class="ch">{esc(name)}</div><table>{inner}</table></div>\n'

# ---- top gaps box, grouped per service ----
gaps_html=""
for name,rows in gaps_by_service:
    items="".join(f'<li><span class="surf">[{esc(r["surface"])}]</span> {esc(r["detail"])}</li>' for r in rows)
    gaps_html+=f'<div class="gsvc"><b>{esc(name)}</b><ul>{items}</ul></div>'

shots=""
for cap,fn in [("WebGL now works (visible Chrome)","webgl-working.png"),
               ("Gmail logged in: niceshopsworkshop@gmail.com","gmail-loggedin.png"),
               ("GitHub browser blocked at 2FA","github-2fa.png")]:
    d=b64(fn)
    if d: shots+=f'<figure><img src="{d}"><figcaption>{esc(cap)}</figcaption></figure>'

ts=os.environ.get("STAMP","")
HTML=f"""<!doctype html><html><head><meta charset="utf-8"><title>AIFCD Golden Self-Test</title><style>
*{{box-sizing:border-box}} body{{margin:0;font:14px/1.45 -apple-system,Segoe UI,Roboto,Arial,sans-serif;background:#0d1117;color:#e6edf3}}
.wrap{{max-width:1200px;margin:0 auto;padding:26px}}
h1{{font-size:25px;margin:0 0 3px}} .sub{{color:#8b949e;margin-bottom:16px}}
.counts span{{display:inline-block;padding:4px 12px;border-radius:20px;margin-right:8px;font-weight:600}}
.cpass{{background:#13361f;color:#3fb950}} .cbad{{background:#3d1418;color:#f85149}} .cdesign{{background:#2b2410;color:#d29922}}
.panel{{border:1px solid #30363d;border-radius:10px;padding:14px 16px;margin:0 0 16px;background:#161b22}}
.panel.bad{{border-color:#f85149}} .panel.bad>h2{{color:#f85149}} .panel.fixed{{border-color:#3fb950}} .panel.fixed>h2{{color:#3fb950}}
h2{{margin:0 0 10px;font-size:16px}}
.gsvc{{margin:0 0 8px}} .gsvc b{{color:#f0b3b0}} .gsvc ul{{margin:3px 0 0;padding-left:18px}} .gsvc li{{margin:2px 0}}
.surf{{color:#8b949e;font-size:12px}}
.grid{{display:grid;grid-template-columns:repeat(2,1fr);gap:14px}}
.card{{border:1px solid #30363d;border-radius:9px;overflow:hidden;background:#0f141b}}
.card .ch{{padding:8px 12px;font-weight:700;font-size:14px;border-bottom:1px solid #30363d}}
.card.hbad .ch{{background:#2a1113;color:#ff7b72;border-bottom-color:#f85149}}
.card.hpass .ch{{background:#0f2417;color:#3fb950}}
.card.hdesign .ch,.card.hmixed .ch{{background:#221c0c;color:#d29922}}
.card table{{width:100%;border-collapse:collapse;font-size:12.5px}}
.card td{{padding:5px 10px;border-bottom:1px solid #1c2230;vertical-align:top}}
.card tr:last-child td{{border-bottom:none}}
td.b{{font-weight:700;text-align:center;width:48px;white-space:nowrap}}
tr.pass td.b{{color:#3fb950}} tr.bad td.b{{color:#f85149}} tr.design td.b{{color:#d29922}} tr.na td.b{{color:#8b949e}}
td.surf{{width:78px;color:#8b949e}} td.det{{color:#c9d1d9}}
.shots{{display:flex;gap:12px;flex-wrap:wrap}} figure{{margin:0;width:340px}} figure img{{width:100%;border:1px solid #30363d;border-radius:8px}}
figcaption{{color:#8b949e;font-size:12px;margin-top:4px}}
.foot{{color:#6e7681;font-size:12px;margin-top:20px;border-top:1px solid #21262d;padding-top:10px}}
@media(max-width:820px){{.grid{{grid-template-columns:1fr}}}}
</style></head><body><div class="wrap">
<h1>AIFCD Golden &mdash; Service / Login / API Self-Test</h1>
<div class="sub">Host: aifcd-golden &nbsp;|&nbsp; {esc(ts)} &nbsp;|&nbsp; grouped per service; every surface (CLI / API / Browser / MCP / Model) tested</div>
<div class="counts"><span class="cpass">{n_pass} PASS</span><span class="cbad">{n_fail} FAIL</span><span class="cdesign">{n_gap} GAP</span><span style="color:#8b949e">/ {len(allr)} surfaces</span></div>

<div class="panel bad"><h2>GAPS &mdash; not working / needs action (by service)</h2>{gaps_html}</div>

<div class="panel fixed"><h2>FIXED this run &mdash; WebGL in the visible Chrome</h2>
Was broken: this desktop has only a virtio GPU, which Chrome blocklists &rarr; it launched the GPU process with <code>--use-gl=disabled</code>, so WebGL had no context. Forced ANGLE+SwiftShader in <code>~/bin/google-chrome-cdp</code> and the desktop <code>Chrome.desktop</code>; WebGL2 now renders (verified on get.webgl.org/webgl2).</div>

<div class="panel"><h2>Proof screenshots</h2><div class="shots">{shots}</div></div>

<h2 style="margin:18px 0 10px">Per-service results</h2>
<div class="grid">{cards}</div>

<div class="foot">Generated by ~/Projects/aifcd-selftest. Contains NO secrets &mdash; only HTTP codes + pass/fail statuses recorded; keys/tokens never written.</div>
</div></body></html>"""
open(os.path.join(ROOT,"selftest-slide.html"),"w").write(HTML)
print("wrote selftest-slide.html  services=%d"%len([1 for _,ids in GROUPS if any(i in res for i in ids)]))
