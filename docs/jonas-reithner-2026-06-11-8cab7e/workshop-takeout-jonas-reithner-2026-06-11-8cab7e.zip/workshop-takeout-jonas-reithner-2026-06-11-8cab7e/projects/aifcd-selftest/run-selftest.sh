#!/usr/bin/env bash
# aifcd golden self-test: exercise EVERY service across EVERY CLI/API surface.
# Writes results.jsonl (one JSON object per surface). NO secrets are ever written.
# Browser + in-session MCP rows are added separately by the orchestrator.
set -uo pipefail
cd "$(dirname "$0")"
set -a; . "$HOME/.env" 2>/dev/null; set +a
TS="$(date +%Y%m%d-%H%M%S)"
OUT="results.jsonl"
: > "$OUT"

rec() { # id service surface status detail
  jq -nc --arg id "$1" --arg s "$2" --arg su "$3" --arg st "$4" --arg d "$5" \
    '{id:$id,service:$s,surface:$su,status:$st,detail:$d}' >> "$OUT"
  printf '[%s] %-22s %-8s %s\n' "$4" "$2" "$3" "$5"
}
hc() { curl -s -o /tmp/st_body -w '%{http_code}' --max-time 40 "$@" 2>/dev/null; }
ANTH_KEY="$(/usr/local/bin/claude-api-key-helper.sh 2>/dev/null)"

echo "=================== LLM / AI APIs ==================="
# Anthropic key slot 1 + 2 (API)
for slot in 1 2; do
  k="CLAUDE_API_KEY_$slot"; key="${!k:-}"
  if [ -z "$key" ]; then rec "anth-k$slot" "Anthropic key$slot" API gap "var $k empty"; continue; fi
  code=$(hc https://api.anthropic.com/v1/messages -H "x-api-key: $key" -H "anthropic-version: 2023-06-01" -H "content-type: application/json" -d '{"model":"claude-haiku-4-5-20251001","max_tokens":5,"messages":[{"role":"user","content":"say ok"}]}')
  [ "$code" = 200 ] && rec "anth-k$slot" "Anthropic key$slot" API pass "HTTP 200 messages" || rec "anth-k$slot" "Anthropic key$slot" API fail "HTTP $code"
done
# Anthropic via claude CLI (uses apiKeyHelper)
out=$(timeout 90 claude -p "Output only the word: ok" 2>&1); rc=$?
if [ $rc -eq 0 ] && echo "$out" | grep -qi ok; then rec anth-cli "Anthropic (claude CLI)" CLI pass "claude -p replied"; else rec anth-cli "Anthropic (claude CLI)" CLI fail "rc=$rc"; fi

# OpenRouter (API: models + chat)
code=$(hc https://openrouter.ai/api/v1/models -H "Authorization: Bearer ${OPENROUTER_API_KEY:-}")
[ "$code" = 200 ] && rec or-models "OpenRouter" API pass "models HTTP 200" || rec or-models "OpenRouter" API fail "models HTTP $code"
ormodel=$(jq -r '[.data[].id]|map(select(test("flash|mini|haiku|gemini-2";"i")))[0] // .data[0].id' /tmp/st_body 2>/dev/null)
code=$(hc https://openrouter.ai/api/v1/chat/completions -H "Authorization: Bearer ${OPENROUTER_API_KEY:-}" -H "content-type: application/json" -d "{\"model\":\"${ormodel:-openai/gpt-4o-mini}\",\"max_tokens\":5,\"messages\":[{\"role\":\"user\",\"content\":\"say ok\"}]}")
[ "$code" = 200 ] && rec or-chat "OpenRouter chat" API pass "chat HTTP 200 ($ormodel)" || rec or-chat "OpenRouter chat" API fail "chat HTTP $code"

# OpenAI (API: models + chat) + codex CLI
code=$(hc https://api.openai.com/v1/models -H "Authorization: Bearer ${OPENAI_API_KEY:-}")
[ "$code" = 200 ] && rec oai-models "OpenAI" API pass "models HTTP 200" || rec oai-models "OpenAI" API fail "models HTTP $code"
oaimodel=$(jq -r '[.data[].id]|map(select(test("gpt-4o-mini|gpt-4.1-mini|o4-mini|gpt-5-mini|gpt-4o";"i")))[0] // (.data[]|select(.id|test("gpt"))|.id) // .data[0].id' /tmp/st_body 2>/dev/null | head -1)
code=$(hc https://api.openai.com/v1/chat/completions -H "Authorization: Bearer ${OPENAI_API_KEY:-}" -H "content-type: application/json" -d "{\"model\":\"${oaimodel:-gpt-4o-mini}\",\"max_tokens\":5,\"messages\":[{\"role\":\"user\",\"content\":\"say ok\"}]}")
[ "$code" = 200 ] && rec oai-chat "OpenAI chat" API pass "chat HTTP 200 ($oaimodel)" || rec oai-chat "OpenAI chat" API fail "chat HTTP $code"
out=$(timeout 120 codex exec "reply with only: ok" 2>&1); rc=$?
if [ $rc -eq 0 ]; then rec oai-cli "OpenAI (codex CLI)" CLI pass "codex exec ran"; else rec oai-cli "OpenAI (codex CLI)" CLI fail "rc=$rc"; fi

# Gemini direct -> expected GAP (sentinel)
out=$(timeout 30 gemini -p "say ok" 2>&1); rc=$?
if [ $rc -eq 0 ] && ! echo "$out" | grep -qiE "error|api key|invalid"; then rec gem-cli "Gemini (gemini CLI)" CLI pass "replied"; else rec gem-cli "Gemini (gemini CLI)" CLI gap "no real key (sentinel) - use OpenRouter"; fi
if [[ "${GEMINI_API_KEY:-}" == %* || -z "${GEMINI_API_KEY:-}" ]]; then rec gem-api "Gemini direct" API gap "GEMINI_API_KEY is sentinel"; else
  code=$(hc "https://generativelanguage.googleapis.com/v1beta/models?key=${GEMINI_API_KEY}"); [ "$code" = 200 ] && rec gem-api "Gemini direct" API pass "HTTP 200" || rec gem-api "Gemini direct" API fail "HTTP $code"; fi
# Gemini via OpenRouter
gmodel=$(jq -r '[.data[].id]|map(select(test("gemini";"i")))[0] // empty' /tmp/st_body 2>/dev/null)
[ -z "$gmodel" ] && gmodel="google/gemini-2.0-flash-001"
code=$(hc https://openrouter.ai/api/v1/chat/completions -H "Authorization: Bearer ${OPENROUTER_API_KEY:-}" -H "content-type: application/json" -d "{\"model\":\"$gmodel\",\"max_tokens\":5,\"messages\":[{\"role\":\"user\",\"content\":\"say ok\"}]}")
[ "$code" = 200 ] && rec gem-or "Gemini via OpenRouter" API pass "HTTP 200 ($gmodel)" || rec gem-or "Gemini via OpenRouter" API fail "HTTP $code ($gmodel)"

echo "=================== Dev / Hosting ==================="
# GitHub CLI
if GH_TOKEN="$GITHUB_TOKEN" gh auth status >/dev/null 2>&1; then rec gh-cli-auth "GitHub (gh auth)" CLI pass "authenticated"; else rec gh-cli-auth "GitHub (gh auth)" CLI fail "gh auth status failed"; fi
ghuser=$(GH_TOKEN="$GITHUB_TOKEN" gh api user --jq .login 2>/dev/null); [ -n "$ghuser" ] && rec gh-cli-api "GitHub (gh api user)" CLI pass "user=$ghuser" || rec gh-cli-api "GitHub (gh api user)" CLI fail "no user"
# GitHub API curl
code=$(hc https://api.github.com/user -H "Authorization: Bearer $GITHUB_TOKEN" -H "Accept: application/vnd.github+json")
[ "$code" = 200 ] && rec gh-api "GitHub" API pass "HTTP 200 /user" || rec gh-api "GitHub" API fail "HTTP $code"
# GitHub active: create + delete throwaway private repo
REPO="aifcd-selftest-$TS"
if GH_TOKEN="$GITHUB_TOKEN" gh repo create "$REPO" --private --add-readme >/dev/null 2>&1; then
  sleep 2
  if GH_TOKEN="$GITHUB_TOKEN" gh repo delete "$ghuser/$REPO" --yes >/dev/null 2>&1; then rec gh-active "GitHub repo create+delete" CLI pass "created+deleted $REPO"; else rec gh-active "GitHub repo create+delete" CLI fail "created but DELETE failed (token scope?) - repo $REPO left"; fi
else rec gh-active "GitHub repo create+delete" CLI fail "create failed"; fi

# Vercel CLI
vuser=$(timeout 40 vercel whoami --token "$VERCEL_TOKEN" 2>/dev/null | tail -1); [ -n "$vuser" ] && rec vc-cli "Vercel (whoami)" CLI pass "user=$vuser" || rec vc-cli "Vercel (whoami)" CLI fail "no whoami"
# Vercel API
code=$(hc https://api.vercel.com/v2/user -H "Authorization: Bearer $VERCEL_TOKEN")
[ "$code" = 200 ] && rec vc-api "Vercel" API pass "HTTP 200 /v2/user" || rec vc-api "Vercel" API fail "HTTP $code"
# Vercel active deploy + remove
VDIR=$(mktemp -d); echo "<h1>aifcd selftest $TS</h1>" > "$VDIR/index.html"
VPROJ="aifcd-selftest-$TS"
durl=$(cd "$VDIR" && timeout 240 vercel deploy --prod --yes --name "$VPROJ" --token "$VERCEL_TOKEN" 2>/dev/null | tail -1)
if echo "$durl" | grep -q "https://"; then
  dcode=$(curl -s -o /dev/null -w '%{http_code}' --max-time 30 "$durl")
  timeout 60 vercel remove "$VPROJ" --yes --token "$VERCEL_TOKEN" >/dev/null 2>&1
  [ "$dcode" = 200 ] && rec vc-active "Vercel deploy+remove" CLI pass "deployed HTTP $dcode, removed" || rec vc-active "Vercel deploy+remove" CLI fail "deploy URL HTTP $dcode"
else rec vc-active "Vercel deploy+remove" CLI fail "no deploy URL"; fi
rm -rf "$VDIR"

echo "=================== Network / SEO ==================="
# Tailscale
if timeout 10 tailscale status >/dev/null 2>&1; then self=$(timeout 10 tailscale status 2>/dev/null | head -1 | awk '{print $2}'); rec ts-cli "Tailscale (status)" CLI pass "connected as ${self:-?}"; else rec ts-cli "Tailscale (status)" CLI fail "status failed/daemon down"; fi
[[ "${TAILSCALE_AUTHKEY:-}" == [REDACTED-TAILSCALE]* ]] && rec ts-key "Tailscale authkey" API pass "[REDACTED-TAILSCALE] format valid (not re-joining)" || rec ts-key "Tailscale authkey" API gap "authkey missing/wrong format"
# DataForSEO
code=$(hc -u "$DATAFORSEO_LOGIN:$DATAFORSEO_PASSWORD" https://api.dataforseo.com/v3/appendix/user_data)
sc=$(jq -r '.status_code // empty' /tmp/st_body 2>/dev/null)
[ "$code" = 200 ] && [ "$sc" = 20000 ] && rec dfs "DataForSEO" API pass "status_code 20000" || rec dfs "DataForSEO" API fail "HTTP $code status $sc"

echo "=================== Email (easyname) ==================="
MAILF=$(mktemp); printf 'From: %s\r\nTo: %s\r\nSubject: aifcd-selftest %s\r\n\r\nself-test message %s\r\n' "$SMTP_USER" "$SMTP_USER" "$TS" "$TS" > "$MAILF"
if timeout 40 curl -s --ssl-reqd "smtp://$SMTP_HOST:587" --mail-from "$SMTP_USER" --mail-rcpt "$SMTP_USER" --upload-file "$MAILF" -u "$SMTP_USER:$SMTP_PASS" >/dev/null 2>&1; then rec smtp "SMTP send (easyname)" API pass "sent to $SMTP_USER via 587"; else rec smtp "SMTP send (easyname)" API fail "send failed"; fi
rm -f "$MAILF"; sleep 5
if timeout 40 curl -s "imaps://$SMTP_HOST:993/INBOX" -u "$SMTP_USER:$SMTP_PASS" -X 'STATUS INBOX (MESSAGES)' >/dev/null 2>&1; then
  found=$(timeout 40 curl -s "imaps://$SMTP_HOST:993/INBOX" -u "$SMTP_USER:$SMTP_PASS" -X "SEARCH SUBJECT \"aifcd-selftest $TS\"" 2>/dev/null | tr -dc '0-9 ')
  [ -n "$(echo $found)" ] && rec imap "IMAP recv (easyname)" API pass "login ok, test mail found" || rec imap "IMAP recv (easyname)" API pass "login ok (mail not yet indexed)"
else rec imap "IMAP recv (easyname)" API fail "login failed"; fi

echo "=================== Google APIs (OAuth) ==================="
TOK="$(google-access-token 2>/dev/null)"
if [ -z "$TOK" ]; then rec g-token "Google OAuth token" CLI fail "mint failed"; else rec g-token "Google OAuth token" CLI pass "access token minted"
  AUTH=(-H "Authorization: Bearer $TOK")
  gget(){ hc "${AUTH[@]}" "$1"; }
  drive_del(){ curl -s -o /dev/null --max-time 30 -X DELETE "${AUTH[@]}" "https://www.googleapis.com/drive/v3/files/$1"; }
  # Gmail
  code=$(gget "https://gmail.googleapis.com/gmail/v1/users/me/profile"); [ "$code" = 200 ] && rec g-gmail "Gmail API" API pass "profile 200" || rec g-gmail "Gmail API" API fail "HTTP $code"
  # Calendar
  code=$(gget "https://www.googleapis.com/calendar/v3/users/me/calendarList?maxResults=1"); [ "$code" = 200 ] && rec g-cal "Calendar API" API pass "calendarList 200" || rec g-cal "Calendar API" API fail "HTTP $code"
  # People
  code=$(gget "https://people.googleapis.com/v1/people/me?personFields=names"); [ "$code" = 200 ] && rec g-people "People API" API pass "me 200" || rec g-people "People API" API fail "HTTP $code"
  # Drive create/read/delete
  code=$(hc "${AUTH[@]}" -X POST "https://www.googleapis.com/drive/v3/files" -H "Content-Type: application/json" -d "{\"name\":\"aifcd-selftest-$TS.txt\"}")
  fid=$(jq -r '.id // empty' /tmp/st_body 2>/dev/null)
  if [ -n "$fid" ]; then rcode=$(gget "https://www.googleapis.com/drive/v3/files/$fid"); drive_del "$fid"; [ "$rcode" = 200 ] && rec g-drive "Drive API" API pass "create+read+delete" || rec g-drive "Drive API" API fail "read HTTP $rcode"; else rec g-drive "Drive API" API fail "create HTTP $code"; fi
  # Docs create/delete
  code=$(hc "${AUTH[@]}" -X POST "https://docs.googleapis.com/v1/documents" -H "Content-Type: application/json" -d "{\"title\":\"aifcd-selftest-$TS\"}"); did=$(jq -r '.documentId // empty' /tmp/st_body 2>/dev/null)
  [ -n "$did" ] && { drive_del "$did"; rec g-docs "Docs API" API pass "create+delete"; } || rec g-docs "Docs API" API fail "HTTP $code"
  # Sheets create/delete
  code=$(hc "${AUTH[@]}" -X POST "https://sheets.googleapis.com/v4/spreadsheets" -H "Content-Type: application/json" -d "{\"properties\":{\"title\":\"aifcd-selftest-$TS\"}}"); sid=$(jq -r '.spreadsheetId // empty' /tmp/st_body 2>/dev/null)
  [ -n "$sid" ] && { drive_del "$sid"; rec g-sheets "Sheets API" API pass "create+delete"; } || rec g-sheets "Sheets API" API fail "HTTP $code"
  # Slides create/delete
  code=$(hc "${AUTH[@]}" -X POST "https://slides.googleapis.com/v1/presentations" -H "Content-Type: application/json" -d "{\"title\":\"aifcd-selftest-$TS\"}"); pid=$(jq -r '.presentationId // empty' /tmp/st_body 2>/dev/null)
  [ -n "$pid" ] && { drive_del "$pid"; rec g-slides "Slides API" API pass "create+delete"; } || rec g-slides "Slides API" API fail "HTTP $code"
  # Forms create/delete
  code=$(hc "${AUTH[@]}" -X POST "https://forms.googleapis.com/v1/forms" -H "Content-Type: application/json" -d "{\"info\":{\"title\":\"aifcd-selftest-$TS\"}}"); foid=$(jq -r '.formId // empty' /tmp/st_body 2>/dev/null)
  [ -n "$foid" ] && { drive_del "$foid"; rec g-forms "Forms API" API pass "create+delete"; } || rec g-forms "Forms API" API fail "HTTP $code"
fi
# TOTP
totp_code=$(timeout 10 totp 2>/dev/null); echo "$totp_code" | grep -qE '^[0-9]{6}$' && rec g-totp "Google TOTP (2FA)" CLI pass "6-digit code generated" || rec g-totp "Google TOTP (2FA)" CLI fail "no code"

echo "=================== Local services ==================="
# Ollama
export OLLAMA_NOPRUNE=1
systemctl --user start ollama 2>/dev/null || (pgrep -x ollama >/dev/null || (nohup ollama serve >/tmp/ollama.log 2>&1 &)); sleep 3
if curl -s --max-time 5 http://127.0.0.1:11434/api/tags >/dev/null 2>&1; then
  have=$(curl -s http://127.0.0.1:11434/api/tags | jq -r '.models[]?.name' | grep -c 'nemotron-3-nano' || true)
  if [ "${have:-0}" -eq 0 ]; then echo "pulling nemotron-3-nano:4b (~2.8GB)..."; timeout 480 ollama pull nemotron-3-nano:4b >/tmp/ollama-pull.log 2>&1; fi
  ans=$(curl -s --max-time 120 http://127.0.0.1:11434/v1/chat/completions -H "Content-Type: application/json" -d '{"model":"nemotron-3-nano:4b","messages":[{"role":"user","content":"say ok"}],"reasoning_effort":"none","max_tokens":10}' | jq -r '.choices[0].message.content // empty' 2>/dev/null)
  [ -n "$ans" ] && rec ollama "Ollama (Nemotron 4B)" API pass "chat reply ok" || rec ollama "Ollama (Nemotron 4B)" API fail "no chat reply"
else rec ollama "Ollama (Nemotron 4B)" API fail "daemon not reachable :11434"; fi
# Whisper
WAV=/tmp/aifcd-whisper-$TS.wav
if espeak-ng -w "$WAV" "the quick brown fox" 2>/dev/null && [ -s "$WAV" ]; then
  txt=$(timeout 120 whisper "$WAV" 2>/dev/null | tr -d '\0');
  echo "$txt" | grep -qiE "quick|brown|fox" && rec whisper "Whisper.cpp (STT)" CLI pass "transcribed sample" || rec whisper "Whisper.cpp (STT)" CLI fail "transcript mismatch"
else rec whisper "Whisper.cpp (STT)" CLI fail "could not synthesize WAV"; fi
rm -f "$WAV" "$WAV".txt 2>/dev/null

echo "=================== Google Search Console ==================="
if command -v gsc-fetch >/dev/null 2>&1; then
  out=$(timeout 60 gsc-fetch 2>&1); rc=$?
  if [ $rc -eq 0 ]; then rec gsc "Google Search Console" CLI pass "gsc-fetch ran"; else echo "$out" | grep -qiE "auth|login|token" && rec gsc "Google Search Console" CLI gap "needs gsc-login (rc=$rc)" || rec gsc "Google Search Console" CLI fail "rc=$rc"; fi
else rec gsc "Google Search Console" CLI gap "gsc-fetch not in PATH"; fi

echo "=================== DONE (shell surfaces) ==================="
jq -s '.' "$OUT" > results.json
echo "Wrote $(jq 'length' results.json) results to results.json"
