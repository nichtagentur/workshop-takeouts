# energy-saas - Workshop Project
Build a SaaS from the Stromzeit energy-price app. Stack is FIXED - do not substitute services:
- Hosting/API/Cron: Cloudflare Workers (deploy with wrangler, name your worker energy-<desktopNN>)
- Auth: Clerk (Google login, use @clerk/clerk-react + @clerk/backend; dev instance)
- Database: Turso (libSQL, one database per participant, use @libsql/client)
- Email: Resend (price-alert emails, max 8 test mails/day - shared 100/day quota!)
- All credentials live in ./.env -- the SINGLE SOURCE OF TRUTH (SSOT). They are NOT
  duplicated here. Never ask for credentials; read them from ./.env (e.g. `set -a; . ./.env; set +a`).
  The keys present in ./.env are listed by name under ## Credentials below.

## Free tier - your resources are your own
This project's tooling and accounts were installed on the workshop base image. Your work
is NOT shared with the other participants: you create and use your OWN database, your OWN
auth app, and your OWN worker. Everything runs on FREE tiers, so stay inside these limits:

- **Cloudflare Workers** (account `[REDACTED-WORKSHOP_EMAIL]`): FREE plan. ~100,000 requests/day
  and 10ms CPU/request; ~100 worker scripts; no custom domain (your worker is served at
  `energy-NN.<sub>.workers.dev`). Deploy your OWN worker named `energy-NN`.
- **Turso**: FREE plan = up to 100 databases + 5GB / 500M row-reads per MONTH. Create your
  OWN db: `turso db create energy-NN` (uses `TURSO_PLATFORM_TOKEN`).
- **Clerk**: FREE plan = unlimited applications, 50k MAU each. Use your OWN dev app.
- **Resend**: FREE plan = 100 emails/DAY + 3,000/month + 5 req/s. Keep test sends small
  (~8/day). The `nichtagentur.at` domain is VERIFIED, so send FROM `[REDACTED-WORKSHOP_EMAIL]`
  (or any `@nichtagentur.at`) to any recipient. DKIM + a `send.*` subdomain (SPF/MX) were
  added at easyname; normal `@nichtagentur.at` mail is unaffected. NOTE: api.resend.com is
  behind Cloudflare WAF -- use `curl` (default Python `urllib` UA gets blocked with err 1010).
## Credentials
Values live ONLY in ./.env (SSOT). These are the variable NAMES it defines -- read them, do not paste them here:
```
CLOUDFLARE_API_TOKEN     # all-power Workers token (own nichtagentur free account)
CLOUDFLARE_ACCOUNT_ID    # 66c2f5e833ad1875b0a294917c4a59c7
CLOUDFLARE_EMAIL         # [REDACTED-WORKSHOP_EMAIL]
TURSO_DATABASE_URL       # libsql:// URL of the sample db
TURSO_AUTH_TOKEN         # db access token
TURSO_PLATFORM_TOKEN     # account token -> each desktop creates its own db
CLERK_PUBLISHABLE_KEY    # pk_test_... (dev instance)
CLERK_SECRET_KEY         # sk_test_...
RESEND_API_KEY           # re_... (full access)
RESEND_FROM              # [REDACTED-WORKSHOP_EMAIL] (verified domain)
```
(Account IDs / non-secret identifiers are shown as comments for orientation; secret values are never written outside ./.env.)
