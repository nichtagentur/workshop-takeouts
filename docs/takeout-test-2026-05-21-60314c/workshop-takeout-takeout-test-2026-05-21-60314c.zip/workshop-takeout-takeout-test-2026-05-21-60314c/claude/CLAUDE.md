# AI Workshop Cloud Desktop

Claude Code on a Hetzner Cloud Desktop. Tooling, accounts, aliases below apply to every clone of this golden.

## Session start (every new session)

State current date+time (system clock) + knowledge cutoff. Identify the participant (below). Identify the workshop day from the schedule below.

```bash
date '+%Y-%m-%d %H:%M %Z (%A)'
cat ~/.workshop/identity.json
```

## Workshop on this golden

**niceshops -- AI Computer Use** (Vibe Coding for Non-Coders: from zero to your own solution). Same curriculum both days; each participant builds their own real solution.

- **Trainer:** Franz Enzenhofer -- [REDACTED-TRAINER_EMAIL]
- **Client contact:** Verena Niess -- verena.niess@niceshops.com

| Date | Location | Hours |
|------|----------|-------|
| 2026-05-27 (Wed) | **Saaz** -- niceshops HQ, Saaz 99, A-8341 Paldau ("White Room") | 09:00-17:00, 12 participants |
| 2026-05-28 (Thu) | **Graz** -- Annenstrasse 23 (near Graz Hbf) | 09:00-17:00, 12 participants |

Tools: Claude Code (primary), MCP servers (Google Sheets, Gmail, Trello, Freshdesk, ...), Gemini VEO3 + Nanobanana, OpenRouter. Real niceshops data (GSC + product feeds) under `~/Data/`. More in `~/WORKSHOP.md`.

If today matches a workshop date: lead with `Today is <date>. This is the niceshops AI Computer Use workshop in <location>.` Else: `Today is <date>. No workshop scheduled.`

## Who is this participant

One participant per desktop. `~/.workshop/identity.json`:

```bash
cat ~/.workshop/identity.json   # displayName, email, instanceLabel
```

- Address by `displayName`.
- `email` = claim token, not a live mailbox here.
- `instanceLabel` = friendly name ("Desktop NN").
- Missing JSON: fall back to `~/Desktop/WHO-AM-I.txt` or `aifcd-whoami`.

## Rules
- Tasks pragmatic, 3-5 min max; simple working code; short non-technical explanations
- New project: `~/Projects/<name>/` with `CLAUDE.md` + `AGENTS.md` symlink
- **NEVER** tell users to do things manually -- YOU do it
- **NEVER use `rm`** -- use `gio trash <file>`
- **ALWAYS** use Chrome
- No emoji (renders as boxes in this terminal)
- You have `sudo`

## Quick start
```bash
claude+ "your task"    # auto-approve
codex+ "your task"     # codex YOLO
gemini+ "your task"    # gemini auto
```

## Password (ALL ACCOUNTS)
```
[REDACTED-WORKSHOP_PASSWORD]
```

## API Keys (`~/.env`, sourced by `~/.bashrc`)

Anthropic key is NOT in `~/.env` -- `/usr/local/bin/claude-api-key-helper.sh` (referenced by `apiKeyHelper` in `~/.claude/settings.json`) supplies it. Don't add `ANTHROPIC_API_KEY` to `~/.env`; it conflicts. See `~/KNOWN-ISSUES.md`.

| Variable | Service | Purpose |
|----------|---------|---------|
| `OPENROUTER_API_KEY` | OpenRouter | 100+ models |
| `OPENAI_API_KEY` | OpenAI | Codex + OpenAI services |
| `GEMINI_API_KEY` | Google | Gemini CLI |
| `GITHUB_TOKEN` | GitHub | gh CLI (nichtagentur, no expiry) |
| `VERCEL_TOKEN` | Vercel | Deploys |
| `TAILSCALE_AUTHKEY` | Tailscale | VPN |
| `DATAFORSEO_LOGIN` / `..._PASSWORD` | DataForSEO | SERP/keywords/backlinks |
| `SMTP_HOST` / `SMTP_USER` / `SMTP_PASS` | easyname.eu | Outbound mail (587 STARTTLS) |
| `GOOGLE_WORKSHOP_EMAIL` / `_PASSWORD` / `_RECOVERY_PHONE` | Google | Workshop demo account (`niceshopsworkshop@gmail.com`) |
| `GOOGLE_WORKSHOP_TOTP_SECRET` | Google | Base32 2FA secret -- AI solves the authenticator prompt itself |
| `GOOGLE_OAUTH_CLIENT_ID` / `_CLIENT_SECRET` / `_REFRESH_TOKEN` | Google | Browserless REST access to all Google APIs |

A value of `%noapikeyset%` means intentionally unprovisioned (e.g. no Codex this workshop) -- tools fail loud, not silent.

## Google automation (workshop demo account)

Full AI control of `niceshopsworkshop@gmail.com` -- browser and API. Skills: `google-login`, `google-2fa`, `google-api`.

- **TOTP:** `~/bin/totp` prints the current 2FA code (`oathtool` + `GOOGLE_WORKSHOP_TOTP_SECRET`). The AI satisfies Google's authenticator prompt with no human.
- **Browser:** `~/bin/google-chrome-cdp` launches Chrome on the signed-in clone profile (`~/.config/google-chrome-cdp`) with remote debugging on `:9222`, `navigator.webdriver=false`. chrome-devtools MCP attaches via `--browserUrl` (set in `~/.claude.json` + `~/.claude-max/.claude.json`). Google blocks fresh logins from MCP/puppeteer-launched Chrome (automation flag) -- always attach to this instead.
- **API:** `~/bin/google-access-token` mints an access token from the OAuth refresh token. GCP project `niceshops-workshop-automation`, app published to production, scopes for Gmail/Drive/Calendar/Docs/Sheets/Slides/Forms/People. Example: `curl -H "Authorization: Bearer $(google-access-token)" https://gmail.googleapis.com/gmail/v1/users/me/profile`.

## Git
```
user.name = nichtagentur
user.email = [REDACTED-WORKSHOP_EMAIL]
init.defaultBranch = main
```

## GitHub / Vercel
- **GitHub:** user `nichtagentur`, email `[REDACTED-WORKSHOP_EMAIL]`, password above
- **Vercel:** account `nichtagentur` via GitHub, token in `~/.env`

## Email

| Email | Purpose |
|-------|---------|
| [REDACTED-WORKSHOP_EMAIL] | GitHub account |
| [REDACTED-WORKSHOP_EMAIL] | Default SMTP sender |
| [REDACTED-WORKSHOP_EMAIL] | Support |
| [REDACTED-WORKSHOP_EMAIL] | AI assistant |

`[REDACTED-WORKSHOP_SMTP_HOST]` | IMAP 993 SSL | SMTP 587 STARTTLS (465 blocked by Hetzner).

## CLI Aliases

| Alias | Description |
|-------|-------------|
| `claude+` / `claude++` | Claude auto-approve / + continue |
| `codex+` / `codex++` | Codex YOLO / + resume |
| `gemini+` / `gemini++` | Gemini auto / + resume |
| `vercel+` | Vercel with token |
| `email` | Open mutt |

## Publishing
- Static sites: `gh repo create && gh pages deploy`
- Apps: `vercel+`

## Tools
- `python3`, `node` -- latest via linuxbrew
- `claude+` / `codex+` / `gemini+` -- latest CLIs
- `gh` (nichtagentur), `vercel+`

## Installing a personal "claw" agent

Telegram + agent bridge -- recommend **MVPClaw**:

```bash
git clone https://github.com/Arthur-Ficial/mvpclaw.git mybot
cd mybot
claude        # then: "make this work"
```

Small single-process Telegram-to-agent bridge (OpenRouter by default, or Claude CLI). The coding agent is the installer.

## Key Files

| File | Purpose |
|------|---------|
| `~/.env` | ALL API keys (single source) |
| `~/.bashrc` | Aliases, sources `~/.env` |
| `~/.claude/CLAUDE.md` | THIS FILE -- master config |
| `~/CLAUDE.md` | Pointer to this file |
| `~/.claude/settings.json` | Claude defaults (`opus[1m]`, effort `medium`) |
| `~/.workshop/identity.json` | Participant name + email + desktop label |
| `~/WORKSHOP.md` | Workshop notes (niceshops detail) |
| `~/KNOWN-ISSUES.md` | Known issues |
| `~/Projects/` | Workshop project folders |
| `~/Screenshots/` | Screenshots |

---

# Workshop tooling (workshop-agnostic)

Lives on every cloned worker.

## What's on this desktop
- `~/Projects/` -- scratch space
- `~/Data/` -- shared sample datasets
- `~/Screenshots/` -- screenshots

## SERP & web data: DataForSEO

`$DATAFORSEO_LOGIN` / `$DATAFORSEO_PASSWORD` in `~/.env`. HTTP Basic Auth against `https://api.dataforseo.com/v3/...`:

```bash
curl -s -u "$DATAFORSEO_LOGIN:$DATAFORSEO_PASSWORD" \
  -H "Content-Type: application/json" \
  -d '[{"keyword":"your keyword","location_code":2040,"language_code":"de","device":"desktop"}]' \
  https://api.dataforseo.com/v3/serp/google/organic/live/advanced | jq '.tasks[0].result[0].items[]?.title' | head
```

Endpoints: `/v3/serp/google/organic/live/advanced` (live SERP), `/v3/keywords_data/google/search_volume/live` (volume + trend), `/v3/serp/google/ai_mode/live/advanced` (AI Mode), `/v3/on_page/instant_pages` (render+audit URL), `/v3/backlinks/summary/live` (backlinks). Shared account -- keep volume sane.

## Common commands

### Beamer -- drag-drop from phone
**Open Beamer (file drop)** opens a drop-zone page; URL in `~/.workshop/beamer-url`. Drops land in `~/Desktop/`.

### `takeout` -- pack work, push to GitHub, email
**Takeout My Work** (or `takeout`): per `~/Projects/` folder strips known API keys, pushes to private workshop-org repo, emails URLs.

## Hard rules
- **Never paste an API key into chat or commit.** `takeout` strips them.
- No emoji (VNC + 16-bit color -> boxes).
- `~/.env` shared across workers -- don't break it.

---

## Local LLM Tooling (preinstalled, not auto-integrated)

Outside `~`, so `takeout` excludes them.

### Nemotron-3-Nano-4B via Ollama
- `ollama` systemd daemon, OpenAI-compat at `http://127.0.0.1:11434/v1`
- Model: `nemotron-3-nano:4b` (2.8 GB)
- Test: `ollama run nemotron-3-nano:4b "hi"`
- API (suppress reasoning):
  ```
  curl -s http://127.0.0.1:11434/v1/chat/completions \
    -H "Content-Type: application/json" \
    -d '{"model":"nemotron-3-nano:4b","messages":[{"role":"user","content":"hi"}],"reasoning_effort":"none"}'
  ```
- NVIDIA Open Model license (commercial OK). Invoke explicitly.

### Whisper.cpp (local CPU transcription)
- Binary: `/opt/whisper.cpp/build/bin/whisper-cli`, wrapper: `/usr/local/bin/whisper`
- Model: `ggml-base.en.bin` (142 MB, English). Usage: `whisper my.wav` -> stdout + `my.wav.txt`. MIT.

## XDG_RUNTIME_DIR

If systemd-user says "Systemd user services unavailable": `echo $XDG_RUNTIME_DIR` should be `/run/user/1000`. If empty: `export XDG_RUNTIME_DIR=/run/user/$(id -u)`. Golden ships `/etc/profile.d/xdg-runtime-dir.sh` so login shells auto-set it.

## Google workshop account (for demos)

A dedicated Google account exists for this workshop's demos (Gmail, Drive, Forms, Calendar, etc.): **niceshopsworkshop@gmail.com** ("Niceshops Workshop"). Its login credentials live in `~/.env` as `GOOGLE_WORKSHOP_EMAIL` / `GOOGLE_WORKSHOP_PASSWORD` (+ `GOOGLE_WORKSHOP_ACCOUNT_NAME`, `GOOGLE_WORKSHOP_RECOVERY_PHONE`). Use it when a demo needs a real Google login.
